package srushti;

abstract class SportsCommitte {

	abstract void vollyball();

	abstract void Kabbadi();
}

abstract class collage extends SportsCommitte {

	void vollyball() {
		System.out.println("Volleyball");
	}

	abstract void TT();

}

class A extends collage {

	void Kabbadi() {
		System.out.println("Kabbadi");
	}

	void cricket() {
		System.out.println("Cricket");
	}

	void TT() {
		System.out.println("TT");
	};

}

public class AbstractionDemoo {

	public static void main(String s[]) {

		A c = new A();
		c.vollyball();
		c.Kabbadi();
		c.cricket();
		c.TT();

	}
}