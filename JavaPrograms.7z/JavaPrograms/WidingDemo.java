package Com.Keerthana;

public class WidingDemo {
	public static void main(String[] args) {
		int x = 7;
		long y = x;
		float z = y;
		System.out.println("Before conversion,int value" + x);
		System.out.println("After conversion,long value" + y);
		System.out.println("After conversion,float value" + z);
	}

}
