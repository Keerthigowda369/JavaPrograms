package Com.Keerthana;

public class Static {
int rollno;
String name;
static String College="GECR";

static void change() {
	String college = "Reva University";
	
	}
public void Student(int r, String n){
	rollno = r;
	name = n;
}
void display() {
	System.out.println();
}
}
