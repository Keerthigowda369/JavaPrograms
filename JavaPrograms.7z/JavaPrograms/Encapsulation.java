package oops;

class Person {
	private String name;
	public int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;

	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;

	}

}

public class Encapsulation {
	public static void main(String[] args) {

		Person[] p = new Person[3];

		for (int i = 0; i < 3; i++) {
			p[i].setName("test"+i);
		}

		for (int i = 0; i < 3; i++) {

			System.out.println(p[i].getName());
		}

	}
}
