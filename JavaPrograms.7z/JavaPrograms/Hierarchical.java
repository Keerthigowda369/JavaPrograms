package oops;

class College {
	void Reasult(int a) {
		System.out.println("B E Students :" + a);

	}
}

class FirstYear extends College {
	void Reasult1(int i, int j) {
		System.out.println("Enter the Total number of 1st class students:" + i);
		System.out.println("Enter the Total number of 2nd class students:" + j);
	}

}

class SecondYear extends College {
	void Reasult2(int k, int l) {
		System.out.println("Enter the Total number of 1st class students : " + k);
		System.out.println("Enter the Total number of 2nd class students : " + l);
	}

}

class ThirdYear extends College {
	void Reasult3(int m, int n) {
		System.out.println("Enter the Total number of 1st class students : " + m);
		System.out.println("Enter the Total number of 2nd class students : " + n);
	}
}

class FinalYear extends College {
	void Reasult4(int o, int p) {
		System.out.println("Enter the Total number of 1st class students : " + 0);
		System.out.println("Enter the Total number of 2nd class students : " + p);
	}
}

public class Hierarchical {
	public static void main(String[] args) {
		College c = new College();
		c.Reasult(30);
		SecondYear f = new SecondYear();
		f.Reasult2(25, 5);
		c.Reasult(30);
		FirstYear u = new FirstYear();
		u.Reasult1(15, 15);

	}

}
