package patterns;

public class Employee {
	int id;
	String name;
	double salary;

	Employee() {
	}

	Employee(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	void printEmployee() {

		System.out.print("Id : " + id);
		System.out.print(" Name : " + name);
		System.out.print("Salary : " + salary);
		System.out.println();
	}

	public static void main(String[] args) {
		Employee obj1 = new Employee(1, " Keerthana ", 40000);
		Employee obj2 = new Employee(2, " Srushti   ", 50000);
		Employee obj3 = new Employee(3, " Soundarya ", 60000);
		Employee obj4 = new Employee(4, " Santhosh  ", 70000);
		Employee obj5 = new Employee(5, " Nithin    ", 80000);

		System.out.println("LIST OF EMPLOYEES");
		System.out.println("***************");
		obj1.printEmployee();
		obj2.printEmployee();
		obj3.printEmployee();
		obj4.printEmployee();
		obj5.printEmployee();

		Employee[] emps = { obj1, obj2, obj3, obj4, obj5 };
		System.out.println("*********************printing using forloop**********************");
		for (int i = 0; i < emps.length; i++) {
			emps[i].printEmployee();

			Employee S1 = new Employee(1, " A ", 30000);
			Employee S2 = new Employee(2, " B ", 40000);
			Employee S3 = new Employee(3, " D ", 50000);
			Employee S4 = new Employee(1, " V ", 60000);
			Employee S5 = new Employee(1, " K ", 80000);

			System.out.println("THE LIST OF EMPLOYEES WORKING IN HAPPIEST MIND TECHNOLOGY COMPANY");
			System.out.println("******************");
			S1.printEmployee();
			S2.printEmployee();
			S3.printEmployee();
			S4.printEmployee();
			S5.printEmployee();

			Employee[] emps2 = { new Employee(1, " A ", 30000), new Employee(2, " B ", 40000),
					new Employee(3, " D ", 50000), new Employee(1, " V ", 60000), new Employee(1, " K ", 80000) };
			System.out.println("*********************print by keerthana**********************");
			for (int j = 0; j < emps2.length; j++) {
				emps2[j].printEmployee();

			}

		}
	}

}
