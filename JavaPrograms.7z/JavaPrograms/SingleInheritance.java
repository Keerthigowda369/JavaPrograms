package oops;

class A {
	void Doing(int j , int g) {

		System.out.println("Enter j:" + j);
		System.out.println("Enter g:" + g);

	}

}

class B extends A {
	void Doing(int j, int g) {

		System.out.println("Enter j:" + j);
		System.out.println("Enter g:" + g);

	}
}

public class SingleInheritance {

	public static void main(String[] args) {
		B b = new B();
		b.Doing(1, 2);

	}
}
