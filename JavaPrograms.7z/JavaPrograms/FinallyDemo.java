package com.vishal;

public class FinallyDemo {

	public static void main(String s[]) {

		try {

			int i = 10 / 0;
			System.out.println(i);

		} catch (Exception e) {
			System.out.println(e);

		}
        
		finally {
			System.out.println("I will execute always");
		}
		

		
		System.out.println("In the last");
		
		
		
		
	}

}
