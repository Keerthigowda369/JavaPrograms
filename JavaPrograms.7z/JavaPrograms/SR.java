package com.day1;

public class SR {
	public static void main(String[] s) {

		int i = 10;

		System.out.println(i++);
		System.out.println(++i);
//Now i=12
		int j = 10;
		System.out.println(j--);
		System.out.println(--j);
// Now j=8 
		if (i % 2 == 0 && j % 2 == 0) {
			System.out.println("Enter the true");

		} else {
			System.out.println("Enter the false");
		}
		int k = 5;
		if (i % 2 == 0 && k % 2 == 0) {
			System.out.println("Enter the true");

		}

		else {
			System.out.println("Enter the false");
		}

		int k1 = 5;
		if (k1 % 2 == 0 && i % 2 == 0) {
			System.out.println("Enter the true");

		}

		else {
			System.out.println("Enter the false");
		}

		if (i % 2 == 0 || k % 2 == 0) {
			System.out.println("Enter the true");

		} else {
			System.out.println("Enter the false");
		}
	}
}

//post fix and prefix