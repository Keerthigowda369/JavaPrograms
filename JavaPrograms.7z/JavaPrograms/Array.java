package com.santhos;

public class Array {
	public static void main(String []s)
	{
		
		int[] array= {2,3,4,5,6};
		for(int element: array) {
		
		System.out.println(element*2);
		
	}
	
	
	}
	

}
