package Com.Keerthana;

public class NarrowingDemo {
	public static void main(String args[]) {

		double d = 1666.66;
		long l = (long)d;
		int i = (int) l;
		System.out.println("Before conversion:" + d);
		System.out.println("After conversion into long type:" + l);
		System.out.println("After conversion into long type:" + i);

	}
}
