package oops;

class Z {
	void Doing1(int j, int g) {

		System.out.println("Enter j:" + j);
		System.out.println("Enter g:" + g);

	}

}

class X extends Z {
	void Doing2(int e, int g) {

		System.out.println("Enter e:" + e);
		System.out.println("Enter g:" + g);

	}
}

class C extends X {
	void Doing3(int k, int g) {

		System.out.println("Enter k:" + k);
		System.out.println("Enter g:" + g);
	}
}

public class Multilevel {
	public static void main(String[] args) {
		C c = new C();
		c.Doing1(4, 6);
		c.Doing2(7, 8);
		c.Doing3(9, 20);
	}

}
