package srushti;

import com.test.*;

class Teacher {
	String name;

	void book() {
		System.out.println("number of books 40");
		System.out.println("book name is biology");

	}
}

class Student extends Teacher {
	void notebook() {
		System.out.println("number of notebooks 100");
		System.out.println("I wrote biology notes");

	}
}
class Test1 extends Test{
	 public void Pen1() {
		 System.out.println("pen name is veer"); 
	 }
}

public class Knowledge {
	public static void main(String[] args) {
		Student s = new Student();
		s.notebook();
		s.book();
		
		
		 

		Test t = new Test();
		Test1 t1 =new Test1();
t.Pen();
t.Pen1();

	}

}

