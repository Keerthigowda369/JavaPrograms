package com.hello;

public class doubles {
	public static void main(String[] s) {
		double num = 1000.5;
		double sth = 20073.6;
		System.out.println("num:" + num);
		System.out.println("sth:" + sth);

	}

}
