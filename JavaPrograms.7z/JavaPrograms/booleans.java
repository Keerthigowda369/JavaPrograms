package com.hello;

public class booleans {
	public static void main(String args[]) {
		boolean sth=true;
		boolean thala=false;
		System.out.println(sth);
		
		System.out.println(thala);
	}
	
	
	

}
