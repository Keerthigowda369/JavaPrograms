package patterns;

import java.util.Scanner;

public class demo1 {

	public static void main(String s[]) {
		Scanner stdIn = new Scanner(System.in);

		System.out.println("Enter the first number");
		String strValue1 = stdIn.nextLine();
		int num1 = Integer.parseInt(strValue1);

		System.out.println("Enter the second number");
		String strValu2 = stdIn.nextLine();
		int num2 = Integer.parseInt(strValu2);

		System.out.println("Enter the calculation operator like + - / * : ");
		String strValue = stdIn.nextLine();
		char operator = strValue.charAt(0);

		int result = 0;

		switch (operator) {

		case '+':
			result = num1 + num2;
			break;
		case '-':
			result = num1 - num2;
			break;
		case '*':
			result = num1 * num2;
			break;
		case '/':
			result = num1 / num2;
			break;

		}

		System.out.println(result);

		System.out.println("After calcalculations add 50 to each number and try the same calculation");
		
		switch (operator) {

		case '+':
			result = num1+50 + num2+50;
			break;
		case '-':
			result = num1+50 - num2+50;
			break;
		case '*':
			result = num1+50 * num2+50;
			break;
		case '/':
			result = num1+50 / num2+50;
			break;

		}
		
		

		System.out.println("After calcalculations add 2000 to each number and try the same calculation");
		
		switch (operator) {

		case '+':
			result = num1+50 + num2+50;
			break;
		case '-':
			result = num1+50 - num2+50;
			break;
		case '*':
			result = num1+50 * num2+50;
			break;
		case '/':
			result = num1+50 / num2+50;
			break;

		}
		
	}

}
