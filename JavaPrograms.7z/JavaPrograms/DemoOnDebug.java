package Com.Keerthana;

public class DemoOnDebug {

	public void mul(int a, int b) {
		int i=a;
		int j=b;
		int result = a*b;
		int result2 = a*b;
		
		System.out.println("***********************");
		System.out.println("result "+ result);
		System.out.println("result2 "+ result2);
	}
public static void main(String[] s) {
	System.out.println("Welcome to v-tech training institute");
	
	DemoOnDebug ob = new DemoOnDebug();
	ob.mul(21,22);
}
	
	

}
