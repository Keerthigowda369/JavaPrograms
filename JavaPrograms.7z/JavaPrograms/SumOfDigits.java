package com.nithin;

import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// sum of digits from the input given user.

		// 1. take input from user scanner
		// String "123" "tewes1100" "1233"
		// iterate the string and get a character
		// check the char if a digit or not
		// if digit add to sum and print

		// 0-48 1-49
		String str = null;
		while (true) {
			System.out.println("Enter a input : ");
			Scanner scanner = new Scanner(System.in);
			str = scanner.nextLine();

			int sum = 0;

			for (int i = 0; i < str.length(); i++) {

				Character c = str.charAt(i);

				if (c.isDigit(c)) {

					int digit = Character.getNumericValue(c);

					sum = sum + digit;

				}
			}

			System.out.println(" The sum is " + sum);
		}
	}

}
