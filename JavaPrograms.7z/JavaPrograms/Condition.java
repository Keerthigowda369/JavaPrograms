package srushti;

final class Company {
	final String Cname = "srushti";

}

class Employee1 {
	int id = 12345;
	String name = "sru";

}

public class Condition {
	public static void main(String args[]) {

		Employee e = new Employee();
		
		System.out.println("enter sru instead of keerthi");

	}

}
