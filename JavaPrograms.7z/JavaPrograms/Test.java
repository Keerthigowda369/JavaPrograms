package com.test;

public class Test {

	public void Pen() {
		System.out.println("pen name is ball");
	}

public void Pen1() {
	
	System.out.println("pen name is veer");

}


	
}


	 
	
