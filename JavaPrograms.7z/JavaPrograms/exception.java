package com.hello;

public class exception {
	public static void main(String s[]) {
		try {
			int i = 10;
			int j = 0;
			int l = i / j;
			System.out.println(l);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
