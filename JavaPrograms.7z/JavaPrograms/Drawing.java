package srushti;

public class Drawing {
	void draw(int i, int j, int k) {
		System.out.println("Drawing the tringle using a i ,j,k:" + i + " " + j + " " + k);
	}

	void draw(int i, int j, int k, int m) {
		System.out.println("Drawing the rectangle :" + i + " " + j + " " + k + " " + m);
	}

	void draw(int i, int j, int k, int m, int n) {
		System.out.println("Drawing the pentagon:" + i + " " + j + " " + k + " " + m + " " + n);
	}

	void draw(int i, int j, int k, int m, int n, int l) {
		System.out.println("Drawing the hexagon:" + i + " " + j + " " + k + " " + m + " " + n + " " + l);
	}

	void printDraw() {
		System.out.println("triangle :");

		System.out.println("rectangle : ");
		System.out.println("pentagon: ");
		System.out.println("hexagon :");
	}

	public static void main(String[] s) {

		Drawing dr = new Drawing();
		dr.draw(1, 2, 3);
		dr.draw(1, 2, 3, 4);
		dr.draw(1, 2, 3, 4, 5);
		dr.draw(1, 2, 3, 4, 5, 6);
		dr.printDraw();

	}
}
