package Com.Keerthana;
class Thread1 extends Thread{
	public void run() {
		System.out.println("Multi1 thread is running...");
		for(int i=200; i<=300; i++)
		{
			System.out.println("Multi1 thread is running..."+i);	
		}
}
}
public class ThereadDemo  extends Thread {
	//class Multi extends Thread {
		public void run() {
		System.out.println("thread is running...");
		for(int i=0; i<=300; i++)
		{
			System.out.println("Multi thread is running..."+i);	
		}
		
		}
		public static void main(String args[]) throws InterruptedException{
			ThereadDemo	 t1=	new ThereadDemo();
			 Thread1 t2=new 	 Thread1 ();
			 
		
			
			t2.start();
			t2.join();
			
			t1.start();
			
		}
		
	}
