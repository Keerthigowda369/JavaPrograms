package srushti;

class StaticDemo {
	static int count = 0;

	private int i;
	private int j;

	public int getI() {
		return i;

	}

	public void setI(int i) {
		this.i = i;
	}

	public int getJ() {
		return j;

	}

	public int setJ() {
		return j;
	}
}

public class Accesmod {
	public static void main(String[] args) {
		StaticDemo obj = new StaticDemo();
		obj.setI(38);
		int ret = obj.getI();
		System.out.println(ret);

	}
}