package patterns;

import java.util.Scanner;

public class Calculator {
	Calculator() {
	};

	int add(int a, int b, int c, int d, int e) {
		int result = a + b + c + d + e;
		return result;
	}

	int sub(int a, int b, int c, int d, int e) {
		int result = a - b - c - d - e;
		return result;
	}

	int mul(int a, int b, int c, int d, int e) {
		int result = a * b * c * d * e;
		return result;
	}

	double div(int a, int b, int c, int d, int e) {
		double result = a / b / c / d / e;
		return result;
	}

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		System.out.println("Enter N1");
		String num1 = S.nextLine();
		int n1 = Integer.parseInt(num1);
		System.out.println("Enter N2");
		String num2 = S.nextLine();
		int n2 = Integer.parseInt(num2);
		System.out.println("Enter N3");
		String num3 = S.nextLine();
		int n3 = Integer.parseInt(num3);
		System.out.println("Enter N4");
		String num4 = S.nextLine();
		int n4 = Integer.parseInt(num4);
		System.out.println("Enter N5");
		String num5 = S.nextLine();
		int n5 = Integer.parseInt(num5);
		Calculator c = new Calculator();

		int i = c.add(n1, n2,n3,n4,n5);
		System.out.println("add value of a and b and c and d and e : " + i);
		int j = c.sub(n1, n2,n3,n4,n5);
		System.out.println("sub value of a and b :" + j);
		int k = c.mul(n1, n2,n3,n4,n5);
		System.out.println("mul value of a and b :" + k);
		double l = c.div(n1, n2,n3,n4,n5);
		System.out.println("div value of a and b :" + l);

	}

}
