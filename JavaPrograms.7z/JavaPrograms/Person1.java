package srushti;

public class Person1 {

	void book(String book1, String book2) {
		System.out.println("book1,book2");
	}

	void book(String book1, String book2, String book3) {
		System.out.println("book1,book2,book3");

	}

	public static void main(String[] args) {

		Person1 p = new Person1();
		p.book("bio", "chemistry");
		p.book("Kannada", "English", "Hindi");
	}

}
