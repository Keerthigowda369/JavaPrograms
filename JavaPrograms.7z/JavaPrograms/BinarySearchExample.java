package Com.Keerthana;

import java.util.Arrays;

public class BinarySearchExample {
	public static void main(String[] s) {
		int arr[] = { 10, 20, 15, 22, 35 };
		Arrays.sort(arr);
		int key = 22;
		int res = Arrays.binarySearch(arr, key);
		if (res >= 0)
			System.out.println(key + " Found at index = " + res);
		else
			System.out.println(key + " Not Found");
		key = 40;
		res = Arrays.binarySearch(arr, key);
		if (res >= 0)
			System.out.println(key + " Found at index = " + res);
		else
			System.out.println(key + " Not Found");
	}
}
