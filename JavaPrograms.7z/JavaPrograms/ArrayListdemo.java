package santhosh;

import java.util.ArrayList;

public class ArrayListdemo {
	public static void main(String[] s) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		list.add(6);
		list.add(7);
		list.add(8);
		list.add(9);
		list.add(10);

		list.get(2);
		list.get(3);
		list.remove(4);
		list.remove(2);

		System.out.println("Enter the number:" + list);
		System.out.println("Enter the get number:" + list.get(3));
		System.out.println("Enter the removed number:" + list.remove(4));
		System.out.println("Enter the  removed number:" + list.remove(2));

		System.out.println("Enter the number:" + list);

		list.get(2);
		list.get(3);
		list.remove(4);
		list.remove(2);

		System.out.println("Enter the number:" + list);
		System.out.println("Enter the get number:" + list.get(1));
		System.out.println("Enter the removed number:" + list.remove(0));
		System.out.println("Enter the  removed number:" + list.remove(2));

		System.out.println("Enter the number:" + list);

	}

}
