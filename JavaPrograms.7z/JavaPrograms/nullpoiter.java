package com.hello;

public class nullpoiter {
	public static void main(String[] args) {
		String s = "Value";
		try {
			System.out.println(s.length());

		}

		catch (Exception e) {
			System.out.println(e);

		}
		System.out.println("testing");

	}

}
