package com.vijay;

public class HelloWorld {

	public static void main(String ars[]) {

		System.out.println("Welcome to V-tech Training Institute");
	}

}
