package com.santhos;

public class sru {
	public static void main(String[] s) {
		
		int[] arr= new int[10];
		
		for(int i=0;i<arr.length; i++) {
			
		
		
		
			System.out.println(i);
		}
		
			
		}


}

