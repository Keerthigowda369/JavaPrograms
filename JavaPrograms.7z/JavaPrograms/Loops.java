package com.santhos;

public class Loops {

	public static void main(String S[]) {

		int arr[] = new int[4];

		for (int i = 0; i < arr.length; i++) {

			arr[i] = 100 + i;

		}

		for (int i = 0; i < arr.length; i++) {

			System.out.println(arr[i]);

		}
	}

}
