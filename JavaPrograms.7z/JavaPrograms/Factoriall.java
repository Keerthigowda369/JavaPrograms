package srushti;
import java.util.Scanner; 
	

public class Factoriall {
	public static void main(String args[]) {
		
Scanner	 s=new Scanner(System.in);
		
	}

}
