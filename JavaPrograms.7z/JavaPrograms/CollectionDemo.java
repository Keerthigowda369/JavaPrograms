package Com.Keerthana;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class CollectionDemo {

	public static void main(String[] s) {

		/*
		 * System.out.println();
		 * System.out.println("///////////now executing ArrayList/////////////");
		 * System.out.println(); ArrayList<String> ar = new ArrayList<String>();
		 * 
		 * ar.add("srushti");
		 * 
		 * ar.add("keerthana"); ar.add("srushti"); ar.add("sowandarya");
		 * 
		 * ar.add("sowandarya"); ar.add("keerthana"); ar.add("ranju"); ar.add("sahana");
		 * ar.size(); System.out.println(ar); System.out.println(ar.size());
		 * System.out.println(ar); ar.addAll(ar); System.out.println(ar);
		 * 
		 * System.out.println();
		 * System.out.println("////////////now executing TreeSet//////////////");
		 * System.out.println();
		 * 
		 * TreeSet<String> tr = new TreeSet<String>();
		 * 
		 * tr.add("srush"); tr.add("srush"); tr.add("keer"); tr.add("srush");
		 * tr.add("sow"); tr.add("keer");
		 * 
		 * tr.size(); System.out.println(tr); System.out.println(tr.size());
		 * 
		 * System.out.println();
		 * System.out.println("/////////now executing TreeMap/////////");
		 * System.out.println();
		 * 
		 * TreeMap<String, Integer> trr = new TreeMap<String, Integer>();
		 * trr.put("srush", 1); trr.put("srush", 2); trr.put("keer", 3);
		 * trr.put("srush", 4); trr.put("sow", 5); trr.put("keer", 6);
		 * 
		 * trr.size(); System.out.println(trr); System.out.println(trr.size());
		 * 
		 * System.out.println();
		 * System.out.println("//////////now executing HashMap//////////");
		 * System.out.println();
		 * 
		 * HashMap<String, Integer> hm = new HashMap<String, Integer>(); hm.put("srush",
		 * 1); hm.put("srush", 1); hm.put("keer", 3); hm.put("srush", 2); hm.put("sow",
		 * 5); hm.put("keer", 6);
		 * 
		 * hm.size(); System.out.println(hm); System.out.println(hm.size());
		 * System.out.println(hm); System.out.println();
		 * System.out.println("/////////now executing HashSet/////////");
		 * System.out.println();
		 * 
		 * HashSet<String> hs = new HashSet<String>(); System.out.println("true:" +
		 * hs.contains(ar));
		 * 
		 * System.out.println("false:" + ar);
		 * 
		 * hs.add("srushti"); hs.add("srushti"); hs.add("keerthana"); hs.add("srushti");
		 * hs.add("sowandarya"); hs.add("keerthana"); hs.add("sowandarya");
		 * hs.add("keerthana"); hs.add("ranju"); hs.add("sahana");
		 * 
		 * System.out.println(hs); System.out.println(hs.size()); hs.remove("srushti");
		 * System.out.println(hs);
		 * 
		 * hs.contains(hs); System.out.println(hs);
		 */

		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(105);
		list.add(100);
		list.add(101);
		list.add(102);
		list.add(103);
		list.add(104);
		list.add(101);
		list.add(101);
		System.out.println("Size of the list : " + list.size());

		Object obj = new ArrayList<Integer>();
		obj = list.clone();

		System.out.println("List elements " + list);

		System.out.println("Element is found or not ?" + list.contains(1001));
		System.out.println("Element is  " + list.get(1));

		HashSet<Integer> hs = new HashSet<Integer>();

		hs.addAll(list);

		System.out.println("Size of the hs : " + hs.size());
		System.out.println("set elements " + hs);

		TreeSet<Integer> ts = new TreeSet<Integer>();

		ts.addAll(list);
		//System.out.println("Size of the hs : " + ts.size());
		//System.out.println("set elements " + ts);

		list.clear();
		System.out.println("After i Clear the list " + list.size());

		Map<Integer, String> map = new HashMap();

		map.put(1, "Green");
		map.put(2, "Pink");
		map.put(3, "White");
		map.put(3, "white");
		map.put(2, "pink");
		map.put(1, "Green");
		map.put(null, "Green");
		map.put(null, "Green1");
		
		System.out.println("Map size " + map.size());
		System.out.println("Map are " + map);
		
		System.out.println("Map are " + map.containsValue("green"));
		
		HashSet<String> st=new HashSet<String>();
		st.add("v");
		st.add("u");
		st.add("a");
		st.add("b");
		System.out.println("has elements are " + st);
		
		
		

	}

}
