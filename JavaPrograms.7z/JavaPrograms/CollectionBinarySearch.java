package Com.Keerthana;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionBinarySearch {
	public static void main(String[] s) {
		ArrayList<Integer> a1 = new ArrayList<Integer>();
		a1.add(1);
		a1.add(2);
		a1.add(3);
		a1.add(10);
		a1.add(20);
		int key = 10;
		int res = Collections.binarySearch(a1, key);
		if (res >= 0)
			System.out.println(key + " Found At Index = " + res);
		else
			System.out.println(key + " NOt Found");
		key = 15;
		res = Collections.binarySearch(a1, key);
		if (res >= 0)
			System.out.println(key + " Found At Index = " + res);
		else
			System.out.println(key + " NOt Found");
	}
}
