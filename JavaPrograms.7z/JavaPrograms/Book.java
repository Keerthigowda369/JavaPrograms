package srushti;

public class Book {
	int id;
	String name;
	int cost;
	String author;

	Book() {

	}

	Book(int id, String name, int cost, String author) {
		this.id = id;
		this.name = name;
		this.cost = cost;
		this.author = author;
	}

	void printBook() {
		System.out.println("////////////Book details///////////////");
		System.out.println();

		System.out.print("id : " + id);

		System.out.print("name:" + name);

		System.out.print("cost:" + cost);

		System.out.print("author:" + author);
		System.out.println();
		System.out.println();

	}

	public static void main(String[] s) {
		Book book1 = new Book(1234, " physics  ", 90, "newton");
		Book book2 = new Book(1484, " Biology  ", 100, " aristotal");
		Book book3 = new Book(1268, " maths    ", 180, "Aryabat");
		Book book4 = new Book(1489, " chemistry", 150, " antoine lavoisier");
		book1.printBook();
		book2.printBook();
		book3.printBook();
		book4.printBook();

	}

}
